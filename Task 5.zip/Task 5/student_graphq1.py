import graphene
import requests

# GraphQL type
class Student(graphene.ObjectType):
    name = graphene.String()
    dob = graphene.String()
    address = graphene.String()
    telephone = graphene.String()
    email = graphene.String()
   
# GraphQL query + resolver
class Query(graphene.ObjectType):
    
    student = graphene.Field(Student)

    def resolve_student(root, info):
       # Port 5001 didn't run so i used 5005 instead for the url for the Student API
       url = "http://127.0.0.1:5050/getStudent"
       r = requests.get(url)
       r.raise_for_status()  # Checks if the request was successful
       data = r.json()  

# Return a Student object with the data from the API
       return Student(
            name=data.get("name"),
            dob=data.get("dob"),
            address=data.get("address"),
            telephone=data.get("telephone"),
            email=data.get("email"),
        )

schema = graphene.Schema(query=Query)

query = """
        {
        student {
        name
        dob
        address
        telephone
        email
        }
    }
"""

result = schema.execute(query)

print(result.data)
print(result)