from flask import Flask
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

class GetStudent(Resource):
    def get(self):
        return {
            "name": "Tre Jones",
            "dob": "1-11-1970",
            "address": "7 the maple, Forest town, Dublin 15",
            "telephone": "8222666",
            "email": "johnsmith@test.com"

        }
api.add_resource(GetStudent, "/getStudent")

# Run the API but port 5001 didn't run so i used 5005 instead
if __name__ == "__main__":
    app.run(debug=True, port=5050)
